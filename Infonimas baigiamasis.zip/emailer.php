<?php
$name = $_POST['vard'];
$email = $_POST['email'];
$message = $_POST['msg'];


?>